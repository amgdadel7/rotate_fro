# let's print our detection model
print(orientation_model)